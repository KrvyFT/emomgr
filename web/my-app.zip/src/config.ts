// 应用程序配置
export const config = {
  API_URL: process.env.REACT_APP_API_URL || 'http://localhost:3000',
  USE_MOCK_DATA: process.env.REACT_APP_USE_MOCK_DATA === 'true' || true,
}; 